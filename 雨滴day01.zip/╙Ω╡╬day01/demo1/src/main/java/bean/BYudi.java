package bean;

import java.util.Arrays;

public class BYudi {

    private int id;
    private int yid;
    private String year;
    private String month;
    private String data;
    private String time;
    private String[] times;
    private int total;

    @Override
    public String toString() {
        return "BYudi{" +
                "id=" + id +
                ", yid=" + yid +
                ", year='" + year + '\'' +
                ", month='" + month + '\'' +
                ", data='" + data + '\'' +
                ", time='" + time + '\'' +
                ", times=" + Arrays.toString(times) +
                ", total=" + total +
                '}';
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getYid() {
        return yid;
    }

    public void setYid(int yid) {
        this.yid = yid;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {

        String[] timesa = time.split(",");
//        System.out.println("打出前："+timesa.toString());
        setTimes(timesa);
        this.time = time;
    }

    public String[] getTimes() {
        return times;
    }

    public void setTimes(String[] times) {

        this.times = times;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }


    public String strs() {
        return "时间："+year+time;
    }
}
