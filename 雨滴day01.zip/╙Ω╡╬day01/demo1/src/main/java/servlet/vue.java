package servlet;

import bean.BYudi;
import com.alibaba.fastjson.JSON;

import dao.Daoimpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/vue")
public class vue extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.setHeader("Access-Control-Allow-Origin", "*");
        List<BYudi> rains = new Daoimpl().find();

               //设置response对数据的编码方式
                    resp.setContentType("text/html");
                 resp.setCharacterEncoding("UTF-8");
                //告诉浏览器解码方式
                resp.setHeader("content-type", "text/html;charset=utf-8");
                 String data = "好好学习!";
                 //获取向客户端写数据的输出流
                 PrintWriter out = resp.getWriter();


        System.out.println("我被访问了");


        Map map=new HashMap();
        //        map.put("13","123");
        //        map.put(123,"123");
        map.put("rains",rains);
        System.out.println(JSON.toJSONString(map));
        out.write(JSON.toJSONString(map));



    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }
}
