package servlet;

import bean.BYudi;
import dao.Dao;
import dao.Daoimpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

@WebServlet("/yudi")
public class Servlet extends HttpServlet {

    int i=0;

    int preyid=1;
    int yid;
    String year;
    String month;
    String data;
    String time;
    int total;

    BYudi bYudi=new BYudi();

    int k=0;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

//        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html; charset=utf-8");
//        resp.setContentType("application/json; charset=utf-8");
        String what = req.getParameter("what");


        Daoimpl daoimpls = new Daoimpl();
//        new Daoimpl().find();
        daoimpls.find();
       if(what.equals("yes")){
           System.out.println("内容为："+what);


           System.out.println("pre:"+preyid+"yid"+yid);
           if(preyid==yid/*k==3*/){

               i=i+1;
               System.out.println("i的值为："+i);

               total=i;


               SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy MM dd HH:mm:ss");
               Date date = new Date(System.currentTimeMillis());
               String str=simpleDateFormat.format(date);


               String[] strArr = str.split(" ");

               yid=Integer.parseInt(strArr[0]+strArr[1]+strArr[2]);
               System.out.println("yid为："+yid);

               year=strArr[0];
               System.out.println("年:"+year);

               month=strArr[1];
               System.out.println("月："+month);

               data=strArr[2];
               System.out.println("日："+data);

               if(time==null){
                   time=strArr[3];
               }else {
                   time=time+","+strArr[3];
               }


               System.out.println("时间："+time);
               System.out.println(str);



               bYudi.setYid(yid);
               bYudi.setYear(year);
               bYudi.setMonth(month);
               bYudi.setData(data);
//               bYudi.setTime(time);
               bYudi.setTime(time);
               bYudi.setTotal(total);

               System.out.println(bYudi);


//               new Daoimpl().update(bYudi);
               daoimpls.update(bYudi);


               resp.getWriter().write("写入数据成功，请继续");

           }else{

               System.out.println("清零重新开始");
              /* k=3;*/
               preyid=yid;

               i=0;
               time=null;


               i=i+1;
               System.out.println("i的值为："+i);

               total=i;


               SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy MM dd HH:mm:ss");
               Date date = new Date(System.currentTimeMillis());
               String str=simpleDateFormat.format(date);


               String[] strArr = str.split(" ");

               yid=Integer.parseInt(strArr[0]+strArr[1]+strArr[2]);
               System.out.println("yid为："+yid);

               year=strArr[0];
               System.out.println("年:"+year);

               month=strArr[1];
               System.out.println("月："+month);

               data=strArr[2];
               System.out.println("日："+data);

               time=strArr[3];
               System.out.println("时间："+time);
               System.out.println(str);


               bYudi.setYid(yid);
               bYudi.setYear(year);
               bYudi.setMonth(month);
               bYudi.setData(data);
//               bYudi.setTime(time);
               bYudi.setTime(time);
               bYudi.setTotal(total);

               System.out.println(bYudi);
//               new Daoimpl().add(bYudi);
               daoimpls.add(bYudi);
               resp.getWriter().write("写入数据成功，请继续");


           }



        }else{
            System.out.println("搞错了");
            resp.getWriter().write("数据写入错误，请检查网址http://localhost:8082/yudi?what=yes或其他问题");
        }


    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        this.doPost(req,resp);
    }
}
