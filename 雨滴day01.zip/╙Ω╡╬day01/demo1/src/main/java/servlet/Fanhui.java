package servlet;

import bean.BYudi;
import dao.Daoimpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


@WebServlet("/rains")
public class Fanhui extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        List<BYudi> rains = new Daoimpl().find();

        req.setAttribute("rains",rains);
//        req.setAttribute("love","i love you");
//        req.getRequestDispatcher("/rain.jsp").forward(req,resp);

        req.setAttribute("love","雨滴统计实验");
        req.getRequestDispatcher("/rain.jsp").forward(req,resp);


    }


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }
}


