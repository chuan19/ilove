package dao;

import bean.BYudi;

import java.util.List;

public interface Dao {

    public List<BYudi> find();

    public void add(BYudi bYudi);

    public void update(BYudi bYudi);


//    public void add_update(BYudi bYudi, String adds);

    public BYudi findone(int id);


}
