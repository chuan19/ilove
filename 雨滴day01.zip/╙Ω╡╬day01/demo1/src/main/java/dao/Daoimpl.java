package dao;


import bean.BYudi;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import utils.JDBCutil;

import java.util.List;

public class Daoimpl implements Dao {

    JdbcTemplate template=new JdbcTemplate(JDBCutil.getDataSource());

    //服务期断开后保存数据
//    String datas="";

    @Override
    public List<BYudi> find() {

        String sql = "SELECT *FROM yudi";

        List<BYudi> rains=template.query(sql,new BeanPropertyRowMapper<BYudi>(BYudi.class));

//        System.out.println(novels);

        for (BYudi i : rains){
            System.out.println(i.toString());

            System.out.println("字符窜"+i.strs());
        }

        return rains;
    }

    @Override
    public void add(BYudi bYudi) {
        BYudi msg = findone(bYudi.getYid());
        if(msg==null){
//            datas="";
            System.out.println("为空新建");
            //        INSERT INTO yudi VALUE(NULL,1,'年份','月份','日期','时间',10);
            String sql = "INSERT INTO yudi VALUE(NULL,?,?,?,?,?,?);";
            template.update(sql,bYudi.getYid(),
                    bYudi.getYear(),bYudi.getMonth(),bYudi.getData(),bYudi.getTime(),bYudi.getTotal());
            System.out.println("写入数据完成");
        }else {
            System.out.println("不空新建，更新"+msg.getTime());
            update(bYudi);
//            add_update(bYudi,msg.getTime());
//            datas=msg.getTime();
        }

    }

    @Override
    public void update(BYudi bYudi) {
//        System.out.println("datas的值"+datas);
        String sql = "UPDATE yudi SET  YEAR=?,month=?,DATA=?,TIME=?,total=? WHERE yid=?;";
        template.update(sql,bYudi.getYear(),bYudi.getMonth(),bYudi.getData(),bYudi.getTime(),bYudi.getTotal(),bYudi.getYid());
        System.out.println("更新完成");
    }


//    @Override
//    public void add_update(BYudi bYudi, String adds) {
//
//        String sql = "UPDATE yudi SET  YEAR=?,month=?,DATA=?,TIME=?,total=? WHERE yid=?;";
//        template.update(sql,bYudi.getYear(),bYudi.getMonth(),bYudi.getData(),adds+","+bYudi.getTime(),bYudi.getTotal(),bYudi.getYid());
//        System.out.println("更新完成");
//    }


    @Override
    public BYudi findone(int id) {
        String sql = "select * from yudi where yid = ?";
         BYudi user = null;
        try {
             user = template.queryForObject(sql,new BeanPropertyRowMapper<BYudi>(BYudi.class), id);

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
            System.out.println(user);
        return user;
    }


}
