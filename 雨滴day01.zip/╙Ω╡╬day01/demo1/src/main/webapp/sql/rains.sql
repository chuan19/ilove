/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 8.0.16 : Database - yudi2020
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`yudi2020` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `yudi2020`;

/*Table structure for table `yudi` */

DROP TABLE IF EXISTS `yudi`;

CREATE TABLE `yudi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yid` int(11) NOT NULL,
  `year` varchar(20) NOT NULL,
  `month` varchar(20) NOT NULL,
  `data` varchar(20) NOT NULL,
  `time` varchar(100) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `yid` (`yid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `yudi` */

insert  into `yudi`(`id`,`yid`,`year`,`month`,`data`,`time`,`total`) values (1,20191001,'2019','10','1','17:54:09,17:54:16,17:54:20,17:54:23,17:54:28,17:54:29',6),(2,20200607,'2020','1','1','08:00:00,12:54:16,14:54:20,17:54:23,17:54:28,19:54:23,19:54:28,',7),(3,20200101,'2020','6','7','16:54:09,17:54:16,18:54:20,19:54:23,19:54:28,19:54:29,21:54:29,22:54:29',8),(4,20200627,'2020','06','27','13:36:16,13:36:16,13:36:25',3);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
