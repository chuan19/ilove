import org.junit.Test;

public class shape {
    public boolean isshar(){
        return true;
    }
    public int getside(){
        return 0;
    }
}



class re extends shape{
    public int getside(int i){
        return i;
    }
}

