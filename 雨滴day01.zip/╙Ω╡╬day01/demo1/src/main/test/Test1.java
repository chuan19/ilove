import dao.Dao;
import dao.Daoimpl;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class Test1 {

    @Test
    public void test1()
    {

        new Daoimpl().find();

        System.out.println("hello ");



    }



    @Test
    public void test2(){


         int yid;
         String year;
         String month;
         String data;
         String time;
         int total;


        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy MM dd HH:mm:ss");
        Date date = new Date(System.currentTimeMillis());
        String str=simpleDateFormat.format(date);


        String[] strArr = str.split(" ");

         yid=Integer.parseInt(strArr[0]+strArr[1]+strArr[2]);
         System.out.println("yid为："+yid);

         year=strArr[0];
        System.out.println("年:"+year);

        month=strArr[1];
        System.out.println("月："+month);

        data=strArr[2];
        System.out.println("日："+data);

        time=strArr[3];
        System.out.println("时间："+time);
        System.out.println(str);


//        System.out.println(strArr.length); // 这里输出3
//        for (int i = 0; i < strArr.length; ++i){
//            System.out.println(strArr[i]);// 这里输出a b c
//        }





    }



}
