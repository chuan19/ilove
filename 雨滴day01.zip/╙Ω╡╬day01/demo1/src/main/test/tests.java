import dao.Daoimpl;
import org.junit.Test;

public class tests {
    @Test
     public void test1(){
         new Daoimpl().findone(3);
    }

}
